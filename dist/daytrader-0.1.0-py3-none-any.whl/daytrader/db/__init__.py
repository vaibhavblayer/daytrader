"""Database module for DayTrader."""

from daytrader.db.store import DataStore

__all__ = ["DataStore"]
