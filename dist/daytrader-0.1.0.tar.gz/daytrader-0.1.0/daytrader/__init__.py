"""DayTrader - AI-powered CLI for Indian stock market day trading."""

__version__ = "0.1.0"
